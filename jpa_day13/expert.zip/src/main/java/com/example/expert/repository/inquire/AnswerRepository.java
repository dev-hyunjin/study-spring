package com.example.expert.repository.inquire;

import com.example.expert.entity.inquire.Answer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AnswerRepository extends JpaRepository<Answer, Long> {
}
