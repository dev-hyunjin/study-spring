package com.example.expert.entity.registration;

import lombok.Getter;

@Getter
public enum CarStatusType {
    ENABLE, DISABLE
}
