package com.example.expert.entity.registration;

public enum CarType {
    LAMBORGHINI, FERRARI, PORSCHE, BMW, BENZ, AUDI, ASTON_MARTIN
}
